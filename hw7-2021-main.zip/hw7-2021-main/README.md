# hw7-2021
Starter Code for HW7 - JavaScript basics with Video
It is the same Starter Code for HW6 Winter 2022
